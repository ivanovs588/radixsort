#include <iostream>
#define ll long long
ll b[(int)6e7], cnt[256], mas[(int)6e7];
// mas is a sortable array, b and cnt are auxiliary arrays
ll* id1 = &mas[0], *id2 = &b[0];

void radix(long long n) {
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < n; j++) cnt[((*(id1+j))>>(8*i)) & 255]++;
        for (int j= 1; j < 256; j++) cnt[j]+=cnt[j - 1];
        for (int j = n - 1; j >= 0; j--) (*(id2 + (--cnt[((*(id1+j))>>(8*i))&255]))) = (*(id1+j));
        for (int j = 0; j < 256;  j++) cnt[j] = 0;
        std::swap(id1,id2);
    }
    for (int j = 0; j < n; j++) cnt[(mas[j]>=0)]++;
    cnt[1]+=cnt[0];
    for (int j = n - 1; j >= 0; j--) b[--cnt[(mas[j]>=0)]] = mas[j];
    cnt[0] = 0;
    cnt[1] = 0;
    for (int j = 0; j < n; j++) mas[j] = b[j];
    return;
}

int main() {
//  YOUR CODE
    return 0;
}
